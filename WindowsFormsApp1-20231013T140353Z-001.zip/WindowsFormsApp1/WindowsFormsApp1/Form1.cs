﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_ClickOld(object sender, EventArgs e)
        {
            //string sSQLconnectionstring = "Server=HPPROBOOK430G8\\SQLEXPRESS;Database=SQLTutorial;Integrated Security=True";
            //string sSQLconnectionstring = "Server=5CD115QHKJ\\SQLEXPRESS01;Database=Test;Integrated Security=True";
            string sSQLconnectionstring = "Server=5CD951173F\\SQLEXPRESS;Database=Test;Integrated Security=True";


            string inputSQL = "SELECT * FROM CUSTOMERS";
            int iRows = 0;
            //string outputText = "";
            SqlConnection conx;
            conx = new SqlConnection();
            conx.ConnectionString = sSQLconnectionstring;
            conx.Open();
            SqlCommand comx = new SqlCommand();
            comx.Connection = conx;
            comx.CommandType = CommandType.Text;
            comx.CommandText = inputSQL;
            SqlDataReader reader = comx.ExecuteReader();
            this.listBox1.Items.Clear();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    this.listBox1.Items.Add(reader.GetString(2));
                    iRows = iRows + 1;
                }
                this.Text = iRows.ToString();
            }
            else
            {
                this.Text = "No rows found.";
            }
            reader.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        
            {
                string inputSQL = "SELECT * FROM CUSTOMERS";
            int iRows = 0;
            SqlDataReader rdr;
            this.listBox1.Items.Clear();

            rdr = SQLConn.ExecuteReader(inputSQL, CommandType.Text);

            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    this.listBox1.Items.Add(rdr.GetString(2));
                    iRows = iRows + 1;
                }
                this.Text = iRows.ToString();
            }
            else
            {
                this.Text = "No rows found.";
            }
            rdr.Close();

        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            //string sSQLconnectionstring = "Server=HPPROBOOK430G8\\SQLEXPRESS;Database=SQLTutorial;Integrated Security=True";
            string sSQLconnectionstring = "Server=5CD115QHKJ\\SQLEXPRESS01;Database=Test;Integrated Security=True";
            string sListSelected = this.listBox1.SelectedItem.ToString();
            string inputSQL = "SELECT * FROM CUSTOMERS WHERE ContactName = '" + sListSelected.Trim() + "'";
            int iRows = 0;
            this.listBox1.Items.Clear();
            //string outputText = "";
            SqlConnection conx;
            conx = new SqlConnection();
            conx.ConnectionString = sSQLconnectionstring;
            conx.Open();
            SqlCommand comx = new SqlCommand();
            comx.Connection = conx;
            comx.CommandType = CommandType.Text;
            comx.CommandText = inputSQL;
            SqlDataReader reader = comx.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    this.listBox1.Items.Add(reader.GetString(2).Trim());
                    int iCustID = reader.GetByte(0);
                    this.txtCustID.Text = iCustID.ToString();
                    this.txtCustName.Text = reader.GetString(1).Trim();
                    this.txtContName.Text = reader.GetString(2).Trim();
                    this.txtAddress.Text = reader.GetString(3).Trim();
                    this.txtCity.Text = reader.GetString(4).Trim();
                    this.txtPostalCode.Text = reader.GetString(5).Trim();
                    this.txtCountry.Text = reader.GetString(6).Trim();
                    iRows = iRows + 1;
                }
                this.Text = iRows.ToString();
            }
            else
            {
                this.Text = "No rows found.";
            }
            reader.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand Command;
            SqlDataAdapter Adapter = new SqlDataAdapter();
            //SqlDataReader DataReader;
            String Sql = "";
            //string sListSelected = this.listBox1.SelectedItem.ToString();

            Sql = "INSERT INTO Customers (CustomerID, CustomerName, ContactName, Address, City, PostalCode, Country) VALUES(1, N'a', N'a', N'a', N'a', N'a', N'a')";


            //string connetionString = "";
            SqlConnection cnn;
           //connetionString = @"Data Source=5CD951173F\SQLEXPRESS;Initial Catalog=T19;User ID=johan;Password=johan1234";
            string connetionString = "Server=5CD115QHKJ\\SQLEXPRESS01;Database=Test;Integrated Security=True";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            
            Command = new SqlCommand(Sql, cnn);
            Adapter.InsertCommand = new SqlCommand(Sql, cnn);
            Adapter.InsertCommand.ExecuteNonQuery();
            Adapter.Dispose();
            Command.Dispose();
            cnn.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlCommand Command;
            SqlDataAdapter Adapter = new SqlDataAdapter();
            //SqlDataReader DataReader;
            String Sql = "";
            //string sListSelected = this.listBox1.SelectedItem.ToString();

            Sql = "UPDATE Customers SET CustomerID ='" + txtCustID.Text + 
                "',CustomerName ='" + txtCustName.Text +
                "', ContactName ='" + txtCustName.Text + 
                "',Address ='" + txtAddress.Text +
                "',City ='" + txtCity.Text +  
                "',PostalCode ='" + txtPostalCode.Text + 
                "',Country ='" + txtCountry.Text + 
                "' WHERE CustomerID = '" + txtCustID.Text + "'";

            //string connetionString = "";
            SqlConnection cnn;
            //connetionString = @"Data Source=5CD951173F\SQLEXPRESS;Initial Catalog=T19;User ID=johan;Password=johan1234";
            string connetionString = "Server=5CD115QHKJ\\SQLEXPRESS01;Database=Test;Integrated Security=True";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            Command = new SqlCommand(Sql, cnn);
            Adapter.InsertCommand = new SqlCommand(Sql, cnn);
            Adapter.InsertCommand.ExecuteNonQuery();
            Adapter.Dispose();
            Command.Dispose();
            cnn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sListSelected = this.listBox1.SelectedItem.ToString();
            string sSQL = "DELETE FROM CUSTOMERS WHERE ContactName = '" + sListSelected.Trim() + "'";
            SQLConn cSQLCLass = new SQLConn();
            cSQLCLass.RunSQL(sSQL,e);

        }
    }
}
