﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.IO;

namespace WindowsFormsApp1
{
    internal class SQLConn
    {
        //static string sConnectionString = "Server=5CD951173F\\SQLEXPRESS;Database=Test;Integrated Security=True";
        static string sConnectionString = "";


        public static SqlDataReader ExecuteReader(String commandText,CommandType commandType)
        {
            SqlConnection conx;
            conx = new SqlConnection();
            conx.ConnectionString = sConnectionString;

            using (SqlCommand cmd = new SqlCommand(commandText, conx))
            {
                cmd.CommandType = commandType;
                //cmd.Parameters.AddRange(parameters);

                conx.Open();
                // When using CommandBehavior.CloseConnection, the connection will be closed when the 
                // IDataReader is closed.
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                return reader;
            }
        }
        public void SelectData(String sSQL, EventArgs e) { 
            SqlCommand sCommand = new SqlCommand();
            SqlConnection conx;
            conx = new SqlConnection();
            conx.ConnectionString = sConnectionString;
            conx.Open();
            conx.Close();
        }
        public void RunSQL(String sSQL, EventArgs e)
        {
            //SqlCommand sCommand = new SqlCommand();
            SqlConnection conx;
            SqlDataAdapter Adapter = new SqlDataAdapter();
            conx = new SqlConnection();
            conx.ConnectionString = sConnectionString;
            conx.Open();
                Adapter.InsertCommand = new SqlCommand(sSQL, conx);
                Adapter.InsertCommand.ExecuteNonQuery();
                Adapter.Dispose();
            //    sCommand.Dispose();
            conx.Close();
        }
        public void InitializeClass(string sPath)
        {
            // Read a text file line by line.
            string textFile = sPath + "\\ini" +
                ".txt";
            string[] lines = File.ReadAllLines(textFile);
            foreach (string line in lines)
            sConnectionString = line;
                    //Console.WriteLine(line);

        }


    }
}
